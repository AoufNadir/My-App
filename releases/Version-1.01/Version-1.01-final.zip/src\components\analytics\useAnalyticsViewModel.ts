import { useMemo } from 'react';
import { Tx, ClientDzd, ClientTransactionDzd } from '../../types';
import {
  AnalyticsSimMode,
  CalculatedStats,
  MonthlyClientRank,
  MonthlyClientRanking,
  SimSellResult
} from './analyticsTypes';

type UseAnalyticsViewModelParams = {
  transactions: Tx[];
  usdtReportMonth: number;
  usdtReportYear: number;
  simMode: AnalyticsSimMode;
  simSellUsdtQty?: string;
  simSellDzdPrice?: string;
  parseAndEvaluate: (expr: string) => number;
  portfolioUsdtAvgBuy: number;
  clientTransactionsDzd: ClientTransactionDzd[];
  clientsDzd: ClientDzd[];
  getClientFullName: (client: ClientDzd) => string;
  t: (key: string) => string;
};

export function useAnalyticsViewModel({
  transactions,
  usdtReportMonth,
  usdtReportYear,
  simMode,
  simSellUsdtQty,
  simSellDzdPrice,
  parseAndEvaluate,
  portfolioUsdtAvgBuy,
  clientTransactionsDzd,
  clientsDzd,
  getClientFullName,
  t
}: UseAnalyticsViewModelParams) {
  const calculatedStats = useMemo<CalculatedStats>(() => {
    let volUsdtBought = 0;
    let volUsdtSold = 0;
    let volEurBought = 0;
    let realizedProfit = 0;

    const startDate = new Date(usdtReportYear, usdtReportMonth, 1).getTime();
    const endDate = new Date(usdtReportYear, usdtReportMonth + 1, 0, 23, 59, 59).getTime();

    transactions.forEach(tx => {
      if (tx.timestamp >= startDate && tx.timestamp <= endDate) {
        if (tx.currency === 'USDT') {
          if (tx.type === 'buy') {
            volUsdtBought += tx.quantity;
          } else if (tx.type === 'sell') {
            volUsdtSold += tx.quantity;
            realizedProfit += (tx.profit || 0);
          }
        } else if (tx.currency === 'EUR') {
          if (tx.type === 'buy') {
            volEurBought += tx.quantity;
          }
        }
      }
    });

    return { volUsdtBought, volUsdtSold, volEurBought, realizedProfit };
  }, [transactions, usdtReportMonth, usdtReportYear]);

  const heatmapData = useMemo(() => {
    const salesByDay = new Map<number, number>();

    const startDate = new Date(usdtReportYear, usdtReportMonth, 1);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(usdtReportYear, usdtReportMonth + 1, 0);
    endDate.setHours(23, 59, 59, 999);

    const startTimestamp = startDate.getTime();
    const endTimestamp = endDate.getTime();

    transactions.forEach(tx => {
      if (tx.type === 'sell' && tx.currency === 'USDT' && tx.timestamp >= startTimestamp && tx.timestamp <= endTimestamp) {
        const txDate = new Date(tx.timestamp);
        const day = txDate.getDate();
        const currentProfit = salesByDay.get(day) || 0;
        const profit = (typeof tx.profit === 'number' && !isNaN(tx.profit)) ? tx.profit : 0;
        salesByDay.set(day, currentProfit + profit);
      }
    });

    return salesByDay;
  }, [transactions, usdtReportMonth, usdtReportYear]);

  const simSellResult = useMemo<SimSellResult>(() => {
    if (simMode !== 'sell_dzd' || !simSellUsdtQty || !simSellDzdPrice || !parseAndEvaluate) return null;
    const qty = parseAndEvaluate(simSellUsdtQty);
    const price = parseAndEvaluate(simSellDzdPrice);
    if (isNaN(qty) || isNaN(price)) return null;

    const profit = (price - portfolioUsdtAvgBuy) * qty;
    return { profit, isProfitable: profit >= 0 };
  }, [simMode, simSellUsdtQty, simSellDzdPrice, portfolioUsdtAvgBuy, parseAndEvaluate]);

  const monthlyClientRanking = useMemo<MonthlyClientRanking>(() => {
    const startDate = new Date(usdtReportYear, usdtReportMonth, 1);
    startDate.setHours(0, 0, 0, 0);
    const endDate = new Date(usdtReportYear, usdtReportMonth + 1, 0);
    endDate.setHours(23, 59, 59, 999);

    const startTimestamp = startDate.getTime();
    const endTimestamp = endDate.getTime();

    const txClientMap = new Map<string, { clientId: string; timestamp: number; isSecondary: boolean }>();
    clientTransactionsDzd.forEach((clientTx) => {
      if (!clientTx.linkedTxId || !clientTx.clientId) return;
      const isSecondary = clientTx.linkRole === 'dzd_receiver';
      const existing = txClientMap.get(clientTx.linkedTxId);
      if (!existing) {
        txClientMap.set(clientTx.linkedTxId, { clientId: clientTx.clientId, timestamp: clientTx.timestamp, isSecondary });
        return;
      }
      if (existing.isSecondary && !isSecondary) {
        txClientMap.set(clientTx.linkedTxId, { clientId: clientTx.clientId, timestamp: clientTx.timestamp, isSecondary });
        return;
      }
      if (existing.isSecondary === isSecondary && clientTx.timestamp > existing.timestamp) {
        txClientMap.set(clientTx.linkedTxId, { clientId: clientTx.clientId, timestamp: clientTx.timestamp, isSecondary });
      }
    });

    const clientNameById = new Map<string, string>();
    clientsDzd.forEach((client) => {
      clientNameById.set(client.id, getClientFullName(client));
    });

    const ranksByClient = new Map<string, MonthlyClientRank>();

    transactions.forEach((tx) => {
      if (tx.currency !== 'USDT') return;
      if (tx.type !== 'buy' && tx.type !== 'sell') return;
      if (!tx.id || tx.timestamp < startTimestamp || tx.timestamp > endTimestamp) return;

      const linkedClient = txClientMap.get(tx.id);
      if (!linkedClient) return;

      const clientId = linkedClient.clientId;
      if (!ranksByClient.has(clientId)) {
        ranksByClient.set(clientId, {
          clientId,
          clientName: clientNameById.get(clientId) || t('portfolio.unknownClient'),
          buyVolumeUsdt: 0,
          sellVolumeUsdt: 0,
          totalVolumeUsdt: 0,
          realizedProfit: 0,
          txCount: 0,
          sellCount: 0
        });
      }

      const row = ranksByClient.get(clientId)!;
      const qty = Number(tx.quantity || 0);
      if (tx.type === 'buy') row.buyVolumeUsdt += qty;
      if (tx.type === 'sell') {
        row.sellVolumeUsdt += qty;
        row.realizedProfit += Number(tx.profit || 0);
        row.sellCount += 1;
      }
      row.txCount += 1;
    });

    const rankedRows = Array.from(ranksByClient.values())
      .map((row) => ({
        ...row,
        totalVolumeUsdt: row.buyVolumeUsdt + row.sellVolumeUsdt
      }))
      .sort((a, b) => {
        if (b.totalVolumeUsdt !== a.totalVolumeUsdt) return b.totalVolumeUsdt - a.totalVolumeUsdt;
        if (b.realizedProfit !== a.realizedProfit) return b.realizedProfit - a.realizedProfit;
        return a.clientName.localeCompare(b.clientName, 'fr');
      });

    const topTradedClient = rankedRows.length > 0 ? rankedRows[0] : null;
    const topProfitableCandidates = rankedRows.filter((row) => row.sellCount > 0);
    const topProfitableClient = topProfitableCandidates.length > 0
      ? [...topProfitableCandidates].sort((a, b) => {
        if (b.realizedProfit !== a.realizedProfit) return b.realizedProfit - a.realizedProfit;
        if (b.totalVolumeUsdt !== a.totalVolumeUsdt) return b.totalVolumeUsdt - a.totalVolumeUsdt;
        return a.clientName.localeCompare(b.clientName, 'fr');
      })[0]
      : null;

    return { rankedRows, topTradedClient, topProfitableClient };
  }, [transactions, clientTransactionsDzd, clientsDzd, getClientFullName, usdtReportMonth, usdtReportYear, t]);

  return {
    calculatedStats,
    heatmapData,
    simSellResult,
    monthlyClientRanking
  };
}

